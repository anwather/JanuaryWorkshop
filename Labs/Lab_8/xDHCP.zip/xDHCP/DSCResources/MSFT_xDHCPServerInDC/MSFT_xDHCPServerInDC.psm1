#
# The Get-TargetResource cmdlet.
#
function Get-TargetResource
{
	param
	(
		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DNSName,

		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$IPAddress,

        [parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PsCredential]$Credential,

        [ValidateSet("Present", "Absent")]
        [System.String]
        $Ensure = "Present"
	)

	# Add the logic here and at the end return hashtable of properties.
        $returnValue = @{
           DNSname   = (Get-DhcpServerInDC).DnsName
           IPAddress = (Get-DhcpServerInDC).IPAddress
           Ensure    = $Ensure
        }
        $returnValue
}

#
# The Set-TargetResource cmdlet.
#
function Set-TargetResource
{    
    param
	(
		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DNSName,

		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$IPAddress,

        [parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PsCredential]$Credential,

        [ValidateSet("Present", "Absent")]
        [System.String]
        $Ensure = "Present"
	)

	# Add the logic here.
    #if($PSBoundParameters.ContainsKey("Ensure")){$null = $PSBoundParameters.Remove("Ensure")}
    if($PSBoundParameters.ContainsKey("Debug")){$null = $PSBoundParameters.Remove("Debug")}


    if ($ensure -eq "Absent") {
      Write-Verbose -Message "Removing DHCP server service authorization entry from DC ..."
      $cimSession = New-CimSession -Credential $Credential -Verbose
      Remove-DhcpServerInDC -CimSession $cimSession -DnsName $DNSName -IPAddress $IPAddress -Verbose
      Write-Verbose -Message "DHCP server service authorization is removed from DC"
    }
    else {
      Write-Verbose -Message "Adding DHCP server service authorization in DC ..."
      Add-DhcpServerSecurityGroup -Verbose
      $cimSession = New-CimSession -Credential $Credential -Verbose
      Add-DhcpServerInDC -CimSession $cimSession -DnsName $DNSName -IPAddress $IPAddress -Verbose
      Write-Verbose -Message "DHCP server service authorization is added in DC"
    }
}

#
# The Test-TargetResource cmdlet.
#
function Test-TargetResource
{
    param
	(
		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$DNSName,

		[parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String]$IPAddress,

        [parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[PsCredential]$Credential,

        [ValidateSet("Present", "Absent")]
        [System.String]
        $Ensure = "Present"
	)

	# Add the logic here and at the end return either $true or $false.

    # TODO: Handle the absent case
    Write-Verbose -Message "Checking if DHCP server service authorization is in DC ..."
    try
    {
        $dhcpInDC = Get-DhcpServerInDC | Where-Object {($_.IPAddress -eq $IPAddress) -AND ($_.DNSname -eq $DNSName)}
        
        if($dhcpInDC)
        {
            Write-Verbose -Message "DHCP server $env:COMPUTERNAME authorization entry is present in DC"
            return $true
        }
        else
        {
            Write-Verbose -Message "DHCP server $env:COMPUTERNAME authorization entry is NOT present in DC"
            return $false
        }
    }
    catch
    {
        Write-Verbose -Message "DHCP server $env:COMPUTERNAME authorization entry is NOT present in DC"
        return $false
    }
}